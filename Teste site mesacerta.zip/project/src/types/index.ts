export interface Restaurant {
  id: string;
  name: string;
  description: string;
  cuisine: string;
  address: string;
  image: string;
  rating: number;
  priceRange: string;
  availableTimes: string[];
}

export interface Reservation {
  id: string;
  restaurantId: string;
  date: string;
  time: string;
  guests: number;
  name: string;
  email: string;
  phone: string;
}
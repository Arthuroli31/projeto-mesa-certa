import { Star } from 'lucide-react';
import { Restaurant } from '../types';

interface RestaurantCardProps {
  restaurant: Restaurant;
  onReserve: (id: string) => void;
}

export function RestaurantCard({ restaurant, onReserve }: RestaurantCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <img
        src={restaurant.image}
        alt={restaurant.name}
        className="w-full h-48 object-cover"
      />
      <div className="p-6">
        <div className="flex justify-between items-start">
          <h3 className="text-xl font-semibold text-gray-900">{restaurant.name}</h3>
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
            {restaurant.priceRange}
          </span>
        </div>
        <p className="mt-2 text-gray-500">{restaurant.description}</p>
        <div className="mt-4 flex items-center">
          <Star className="h-5 w-5 text-yellow-400" />
          <span className="ml-1 text-sm text-gray-600">{restaurant.rating}</span>
          <span className="mx-2 text-gray-300">|</span>
          <span className="text-sm text-gray-600">{restaurant.cuisine}</span>
        </div>
        <p className="mt-2 text-sm text-gray-600">{restaurant.address}</p>
        <button
          onClick={() => onReserve(restaurant.id)}
          className="mt-4 w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors"
        >
          Reservar Mesa
        </button>
      </div>
    </div>
  );
}
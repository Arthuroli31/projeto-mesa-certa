export const restaurants = [
  {
    id: '1',
    name: 'Cantina Italiana',
    description: 'Autêntica culinária italiana em um ambiente acolhedor e romântico.',
    cuisine: 'Italiana',
    address: 'Rua das Flores, 123 - São Paulo',
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4',
    rating: 4.8,
    priceRange: '$$$',
    availableTimes: ['18:00', '19:00', '20:00', '21:00']
  },
  {
    id: '2',
    name: 'Sabor do Mar',
    description: 'Os melhores frutos do mar da cidade com vista para o oceano.',
    cuisine: 'Frutos do Mar',
    address: 'Av. Atlântica, 456 - Rio de Janeiro',
    image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836',
    rating: 4.6,
    priceRange: '$$',
    availableTimes: ['12:00', '13:00', '19:00', '20:00']
  },
  {
    id: '3',
    name: 'Churrascaria Brasa',
    description: 'O melhor churrasco brasileiro com cortes premium.',
    cuisine: 'Churrascaria',
    address: 'Rua do Fogo, 789 - Porto Alegre',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947',
    rating: 4.9,
    priceRange: '$$$',
    availableTimes: ['12:00', '13:00', '14:00', '19:00', '20:00', '21:00']
  }
];
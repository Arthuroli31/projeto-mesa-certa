import { useState } from 'react';
import { Header } from './components/Header';
import { RestaurantCard } from './components/RestaurantCard';
import { restaurants } from './data/restaurants';

function App() {
  const [selectedRestaurant, setSelectedRestaurant] = useState<string | null>(null);

  const handleReserve = (id: string) => {
    setSelectedRestaurant(id);
    // TODO: Implement reservation modal
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Encontre e Reserve os Melhores Restaurantes
          </h2>
          <p className="mt-3 max-w-2xl mx-auto text-xl text-gray-500 sm:mt-4">
            Descubra uma experiência gastronômica única e faça sua reserva em poucos cliques
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {restaurants.map((restaurant) => (
            <RestaurantCard
              key={restaurant.id}
              restaurant={restaurant}
              onReserve={handleReserve}
            />
          ))}
        </div>
      </main>

      <footer className="bg-white mt-12">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <p className="text-center text-gray-500">
            © 2025 MesaCerta. Todos os direitos reservados.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;